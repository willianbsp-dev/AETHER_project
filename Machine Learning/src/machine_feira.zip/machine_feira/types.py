"""Tipos de dados fundamentais do sistema AETHER."""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum, auto


class Gesture(Enum):
    NONE = auto()

    CLICK_LEFT = auto()
    CLICK_RIGHT = auto()
    PINCH = auto()

    MAXIMIZE = auto()
    RESTORE = auto()
    MINIMIZE = auto()

    SWIPE_LEFT = auto()
    SWIPE_RIGHT = auto()

    SCROLL = auto()

    ZOOM_IN = auto()
    ZOOM_OUT = auto()

    PAGE_FORWARD = auto()
    PAGE_BACK = auto()
    UNDO = auto()

    DWELL_CLICK = auto()

    VOICE_ACTIVATE = auto()
    CONFIRM = auto()

    PAUSE_TOGGLE = auto()
    KEYBOARD_TOGGLE = auto()


@dataclass(frozen=True)
class Point:
    x: float
    y: float
    z: float = 0.0


@dataclass
class GestureEvent:
    gesture: Gesture
    cursor: Point
    amount: int = 0
    dwell_progress: float = 0.0
    trail: list[Point] = field(default_factory=list)


@dataclass(frozen=True)
class GestureEvent:
    gesture: Gesture
    cursor: Point
    amount: int = 0
    dwell_progress: float = 0.0
    trail: list[Point] | None = None