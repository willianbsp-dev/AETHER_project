
    
  
"""Reconhecimento determinístico de gestos do AETHER com a nova tabela e sensibilidades expandidas."""

from __future__ import annotations

from collections import deque
from dataclasses import dataclass
import math
from time import monotonic
from typing import Deque, Sequence

from .filter import OneEuroFilter, PointFilter
from .trajectory import CircleConfig, CircleTrajectoryRecognizer
from .types import Gesture, GestureEvent, Point

# Índices MediaPipe Hands
WRIST = 0
THUMB_CMC = 1
THUMB_MCP = 2
THUMB_IP = 3
THUMB_TIP = 4
INDEX_MCP = 5
INDEX_PIP = 6
INDEX_DIP = 7
INDEX_TIP = 8
MIDDLE_MCP = 9
MIDDLE_PIP = 10
MIDDLE_DIP = 11
MIDDLE_TIP = 12
RING_MCP = 13
RING_PIP = 14
RING_DIP = 15
RING_TIP = 16
PINKY_MCP = 17
PINKY_PIP = 18
PINKY_DIP = 19
PINKY_TIP = 20


@dataclass(frozen=True)
class GestureConfig:
    """Configurações e limiares de sensibilidade (com margens ampliadas)."""
    pinch_distance_start: float = 0.065
    pinch_distance_release: float = 0.095
    air_click_bend_threshold: float = 0.025
    double_click_time_window: float = 0.45
    
    scroll_threshold: float = 0.022
    swipe_threshold: float = 0.090
    swipe_window_seconds: float = 0.45
    
    two_hand_spread_threshold: float = 0.110
    two_hand_window_seconds: float = 0.50
    
    zoom_move_threshold: float = 0.060
    pause_fist_hold_seconds: float = 0.80
    calibration_samples: int = 21
    dwell_seconds: float = 0.50
    dwell_radius: float = 0.018
    
    cooldown_seconds: float = 0.35
    circle_config: CircleConfig = CircleConfig()


@dataclass
class _TimedPoint:
    p: Point
    time: float


class HandGestureRecognizer:

    def __init__(self, config: GestureConfig | None = None) -> None:
        self.config = config or GestureConfig()
        self._circle_tracker = CircleTrajectoryRecognizer(self.config.circle_config)

        self._cursor_filter = PointFilter(min_cutoff=1.0, beta=0.01)
        self._pinch_filter = OneEuroFilter(min_cutoff=1.2, beta=0.01)
        self._two_hand_filter = OneEuroFilter(min_cutoff=0.8, beta=0.005)

        self._is_pinching = False
        self._last_air_click_time = 0.0
        self._air_click_pending = False

        self._scroll_accumulator = 0.0
        self._scroll_return_direction = 0
        self._previous_filtered_index: Point | None = None

        self._fist_start_time: float | None = None
        self._fist_fired = False

        self._palm_history: Deque[_TimedPoint] = deque(maxlen=30)
        self._zoom_start_y: float | None = None

        self._last_discrete_action = 0.0

        # Calibração explícita esperada pelo projeto/testes.
        self.calibrated = False


    def apply_tremor_filter(self, strength: float) -> None:
        """Ajusta a suavização do cursor para reduzir tremores."""

        strength = max(0.0, min(1.0, float(strength)))

        min_cutoff = 1.6 - (strength * 1.0)
        beta = 0.015 + (strength * 0.025)

        self._cursor_filter = PointFilter(
            min_cutoff=min_cutoff,
            beta=beta,
        )


    # daqui para baixo continuam os outros métodos
    # def update(...)
    # def reset(...)
    # etc.

